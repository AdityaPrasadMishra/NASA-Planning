#/usr/bin/env bash

# clean directory of temporary files generated during planning
rm -f output output.sas sas_plan
rm -f *r-*.pddl obs.dat *.stats stdout.txt
rm -f exp.dat plan.dat temp.pddl
rm -f *~ *'#'
rm -f *.pyc
