from  grounder.parser_interface import pddl

